#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main()
{
    char str1[1000],str2[1000];
    int i,j,a1,a2,m=0;

    printf("Enter first String:");
    scanf("%s",&str1);

    printf("Enter second String:");
    scanf("%s",&str2);

    a1=strlen(str1);
    a2=strlen(str2);

    if(a1<a2)
    {
        j=a2;
    }
    else
    {
        j=a1;
    }

    for(i=0;i<j;i++)
    {
        if(str1[i] != str2[i])
            m++;
    }

    printf("Haming Distance: %d\n",m);

    return 0;
}
