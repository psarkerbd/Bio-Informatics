#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void frequency(char dna[])
{
    int i=0;
    double A=0,T=0,C=0,G=0;

    int length=strlen(dna);

    for(i=0;i<length;i++)
    {
        if(dna[i]=='A')
        {
            A++;
        }
        else if(dna[i]=='T')
        {
            T++;
        }
        else if(dna[i]=='C')
        {
            C++;
        }
        else
        {
            G++;
        }
    }

    printf("frequency of A = %.2lf , T=%.2lf , C=%.2lf , G=%.2lf\n",A,T,C,G);

    A=A/length;
    T=T/length;
    C=C/length;
    G=G/length;

    printf("percentage of DNA:\nA=%.2lf%%\nT=%.2lf%%\nC=%.2lf%%\nG=%.2lf%%\n");


}

int main()
{
    char dna[100];

    printf("Enter a DNA sequence:");

    while(scanf("%s",dna))
    {
        strupr(dna);

        frequency(dna);

        printf("\n");

        printf("Enter a DNA sequence:");
    }


    return 0;

}
