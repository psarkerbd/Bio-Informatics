#include <stdio.h>
#include <string.h>

char dna[1000];

void complementary(char dna[])
{
    int j=0;
    int length=strlen(dna);

    for(j=0;j<length;j++)
    {
        if(dna[j]=='A')
        {
            dna[j]='T';
        }
        else if(dna[j]=='T')
        {
            dna[j]='A';
        }
        else if(dna[j]=='C')
        {
            dna[j]='G';
        }
        else
        {
            dna[j]='C';
        }
    }

}
int main()
{
    int i;

    printf("Enter a DNA sequence:");

    while(scanf("%s",dna))
    {

        strupr(dna);

        complementary(dna);

        int length=strlen(dna);

        printf("\nComplementary stand of that DNA:");
        for(i=0;i<length;i++)
        {
            printf("%c",dna[i]);
        }

        printf("\n\n");

        printf("Enter a DNA sequence:");
    }

    return 0;

}
