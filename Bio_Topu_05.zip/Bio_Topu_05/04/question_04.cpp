#include<stdio.h>
#include<string.h>

#define up 1
#define left 2
#define diag 3

char b[100][100];
int c[100][100];

void PRINT_LCS(char x[],int i,int j)
{
    if(i==0 || j==0)
        return;
    if(b[i][j]==diag)
    {
        PRINT_LCS(x,i-1,j-1);
        printf("%c",x[i-1]);
    }
    else if (b[i][j]==up)
    {
        PRINT_LCS(x,i-1,j);
    }
    else
    {
        PRINT_LCS(x,i,j-1);
    }
}

void LCS_LENGTH(char x[],int m,char y[],int n)
{
    int i,j;

    for(i=1;i<=m;i++)
    {
        c[i][0]=0;
    }
    for(j=0;j<n;j++)
    {
        c[0][j]=0;
    }

    for(i=1;i<=m;i++)
    {
        for(j=1;j<=n;j++)
            {
                if(x[i-1]==y[j-1])
                {
                    c[i][j]=c[i-1][j-1]+1;
                    b[i][j]=diag;
                }

                else if(c[i-1][j]>=c[i][j-1])
                {
                    c[i][j]=c[i-1][j];
                    b[i][j]=up;
                }

                else
                {
                    c[i][j]=c[i][j-1];
                    b[i][j]=left;
                }
            }
    }

}

int main()
{
    char x[100],y[100];

    int a,b,i,j;

    printf("Enter the first DNA sequence: ");
    gets(x);

    printf("Enter the second DNA sequence: ");
    gets(y);

    a=strlen(x);
    b=strlen(y);

    LCS_LENGTH(x,a,y,b);

    printf("The LCS is:\n");
    PRINT_LCS(x,a,b);
    printf("\n");
}


