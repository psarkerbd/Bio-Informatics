#include<bits/stdc++.h>
using namespace std;

#define fast ios_base::sync_with_stdio(0)

int main()
{
    fast;

    string dna_sequence;
    cin >> dna_sequence;

    int len = dna_sequence.length();

    for(int i=0; i<len; i++)
    {
        if(dna_sequence[i] == 'A') cout << "T";
        else if(dna_sequence[i] == 'T') cout << "A";
        else if(dna_sequence[i] == 'C') cout << "G";
        else if(dna_sequence[i] == 'G') cout << "C";
    }

    return 0;
}
