#include<bits/stdc++.h>

#define white 0
#define gray 1
#define black -1
#define nil -2
#define mem(c , v) memset(c , v , sizeof(c))

using namespace std;

const int high = 100;

string first, second;

int b[high][high],c[high][high];

int first_size=0, second_size=0;

void print_LCS(int i, int j)
{
    if(i==0 or j==0)
    {
        return;
    }

    if(b[i][j] == white)
    {
        print_LCS(i-1,j-1);
        cout << first[i-1];
    }

    else if(b[i][j] == gray)
    {
        print_LCS(i-1,j);
    }

    else
    {
        print_LCS(i,j-1);
    }
}

void LCS()
{
    memset(b,0 , sizeof(b));
    memset(c,0 , sizeof(c));

    for(int i=1;i<=first_size;i++)
    {
        for(int j=1;j<=second_size;j++)
        {
            if(first[i-1] == second[j-1])
            {
                c[i][j] = c[i-1][j-1]+1;
                b[i][j] = white;
            }

            else if(c[i-1][j] >= c[i][j-1])
            {
                c[i][j] = c[i-1][j] ;
                b[i][j] = gray;
            }

            else
            {
                c[i][j] = c[i][j-1];
                b[i][j] = black;
            }
        }
    }

//    for(int i=0;i<=m;i++)
//    {
//        for(int j=0;j<=n;j++)
//        {
//            cout << c[i][j] << " ";
//        }
//
//        cout << "\n";
//    }

    cout << "The Alignment is : \n";

    print_LCS(first_size , second_size);
}

int main()
{
    while(cin >> first >> second)
    {
        first_size = first.size();
        second_size = second.size();
        //cout << m << " " << n ; cout << "\n";

        LCS();

        cout << "\n";
    }

    return 0;
}

/*

ABCBDAB BDCABA
BFIDNCEE FGDINBE

*/

