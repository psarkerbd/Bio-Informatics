# Python
# Version: 2.7

from __future__ import print_function;

DNA = {
    'A': 1,
    'T': 2,
    'C': 3,
    'G': 4
}

dna_sequence = raw_input();

length = len(dna_sequence);

visited = set();

for i in range(length):
    visited.add(dna_sequence[i]);
#print visited;

totalsum = 0;

for item in visited:
    total = dna_sequence.count(item);
    #print total
    print (item , ' has ' , total , ' times');
    totalsum = totalsum + total;
#print (totalsum)

# get percentage

for item in visited:
    per = (dna_sequence.count(item) * 100.0) / length;
    print ("Percentage of " , item , ' is : ' , per , '%');

# l-mar (answer of (ii) )

for i in range(length - 2 + 1):
    tmp = "";
    for j in range(i , i+2):
        tmp = tmp + str(dna_sequence[j]);
    print (tmp);



