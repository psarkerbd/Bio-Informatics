#include<bits/stdc++.h>
using namespace std;

#define fast ios_base::sync_with_stdio(0)

int main()
{
    fast;
    string x , y;
    cin >> x >> y;

    int len = x.length() , cnt=0; // Let, length are same

    for(int i=0; i<len; i++)
    {
        if(x[i] == y[i]) cnt++;
    }

    cout << "Haming Distance is : " << cnt << "\n";

    return 0;
}
