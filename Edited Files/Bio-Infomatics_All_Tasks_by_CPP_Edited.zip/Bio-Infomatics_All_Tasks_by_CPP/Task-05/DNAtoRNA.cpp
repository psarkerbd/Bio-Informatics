// Task-05: DNA to RNA
// Author: Pranta Sarker

#include<iostream>
#include<string>
#include<utility>
#include<algorithm>
#include<map>

using namespace std;

char DNA[]={'A', 'T', 'C', 'G'}; // DNA array nisi, zekhane DNA r sob nucleotide gula ache
string DNAsequence; // DNAsequence name e ekta string variable nisi 

void generateDNASequence(int limit) // limit re pass korsi, limit mane ami koto length er DNA sequence chai
{
    DNAsequence="";

    cout << "\n";

    for(int i=0; i<limit; i++)
    {
        int indx = rand() % 4; // 0 theke 3 porzonto random number generate korsi

        DNAsequence += DNA[indx]; // oi random number er jonno DNA nucleotide ke oi string variable DNAsequence e add korsi

        //cout << DNA[indx];
    }

    cout << DNAsequence << "--> DNA"; // DNA sequence re printf korsi

    cout << "\n";


    cout << "(CONVERT)";

    cout << "\n";
	
	// eikhane DNA sequence re RNA te convert korsi, just T r jaygay U

    for(int i=0; i<DNAsequence.length(); i++)
    {
        if(DNAsequence[i] == 'T') cout << "U";

        else
        {
            cout << DNAsequence[i];
        }
    }

    cout << "--> RNA";
}

int main()
{
    int len;

    cout << "Enter Length to see Random DNA Sequence: ";

    while(cin >> len)
    {
        //cout << "\nDNA Sequence is : ";

        generateDNASequence(len); // function call korsi

        cout << "\n\nEnter Length to see Random DNA Sequence: ";
    }

    return 0;
}

