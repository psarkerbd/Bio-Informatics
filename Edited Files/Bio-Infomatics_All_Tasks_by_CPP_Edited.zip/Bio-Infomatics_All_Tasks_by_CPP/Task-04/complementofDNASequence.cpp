// Task-04: Complement of DNA Sequence
// Author: Pranta Sarker

#include<iostream>
#include<string>
#include<utility>
#include<algorithm>
#include<map>

using namespace std;

char DNA[]={'A', 'T', 'C', 'G'}; // DNA array nisi, zekhane DNA r sob nucleotide gula ache
string DNAsequence; // DNAsequence name e ekta string variable nisi 

void generateDNASequence(int limit) // limit re pass korsi, limit mane ami koto length er DNA sequence chai
{
    DNAsequence="";

    cout << "\n";

    for(int i=0; i<limit; i++)
    {
        int indx = rand() % 4; // 0 theke 3 porzonto random number generate korsi

        DNAsequence += DNA[indx]; // oi random number er jonno DNA nucleotide ke oi string variable DNAsequence e add korsi

        cout << DNA[indx]; // oi random number er jonno DNA nucleotide print korsi
    }

    cout << "\n";


    for(int i=0; i<DNAsequence.length(); i++)
    {
        cout << "|";
    }

    cout << "\n";

    for(int i=0; i<DNAsequence.length(); i++) // Complement of DNA Sequence ber korsi mane A hoile T, T hoile A, C hoile G eivabe
    { 
        if(DNAsequence[i] == 'A') cout << "T";
        else if(DNAsequence[i] == 'T') cout << "A";
        else if(DNAsequence[i] == 'C') cout << "G";
        else if(DNAsequence[i] == 'G') cout << "C";
    }
}

int main()
{
    int len;

    cout << "Enter Length to see Random DNA Sequence: ";

    while(cin >> len)
    {
        //cout << "\nDNA Sequence is : ";

        generateDNASequence(len); // function call korsi

        cout << "\n\nEnter Length to see Random DNA Sequence: ";
    }

    return 0;
}
