// Task-02: Generate Random RNA Sequence for K length
// Author: Pranta Sarker

#include<iostream>
#include<string>
#include<utility>
#include<algorithm>

using namespace std;

char RNA[]={'A' , 'U', 'C', 'G'}; // RNA array nisi, zekhane RNA r sob nucleotide gula ache

void generateRNASequence(int limit) // limit re pass korsi, limit mane ami koto length er DNA sequence chai
{
    while(limit--)
    {
        int indx = rand() % 4; // 0 theke 3 porzonto random number generate korsi

        cout << RNA[indx]; // oi random number er jonno RNA nucleotide print korsi
    }
}

int main()
{
    int len;

    cout << "Enter Length to see Random RNA Sequence: ";

    while(cin >> len)
    {
        cout << "\nRNA Sequence is : ";

        generateRNASequence(len); // function call korsi

        cout << "\n\nEnter Length to see Random RNA Sequence: ";
    }

    return 0;
}
