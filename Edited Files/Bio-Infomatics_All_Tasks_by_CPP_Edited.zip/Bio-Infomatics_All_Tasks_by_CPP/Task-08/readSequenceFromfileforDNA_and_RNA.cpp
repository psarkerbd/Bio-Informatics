//#include<iostream>
//#include<string>
//#include<cstring>
//#include<map>
//#include<vector>
//#include<utility>
//#include<random>
//#include<set>
//#include<file>

#include<bits/stdc++.h>

using namespace std;

typedef map<string, int>mpsb;
typedef vector<string>vs;

char DNA[4] = {'A' , 'T' , 'C' , 'G'}; // DNA array nisi, zekhane DNA r sob nucleotide gula ache
char RNA[4] = {'A' , 'U' , 'C' , 'G'}; // RNA array nisi, zekhane RNA r sob nucleotide gula ache

string dna = "" , rna = ""; // dna ar rna name e duita string variable nisi 
int lmar; // lmar name a ekta global integer variable nisi jeta by default 0 diye initialize kora

mpsb mp; // string and bool type ekta map nisi
vs resDNA, resRNA; // resDNA ar resRNA name e duita string type er vector nisi

//void takeDNASequence(int limit)
//{
//    int i=0;
//
//    for(i=0; i<limit; i++)
//    {
//        int range = (3 - 0) + 1;
//        int indx = ( rand() % range ) + 0;
//        dna += DNA[indx];
//    }
//}
//
//void takeRNASequence(int limit)
//{
//    int i=0;
//
//    for(i=0; i<limit; i++)
//    {
//        int range = (3 - 0) + 1;
//        int indx = ( rand() % range ) + 0;
//        rna += RNA[indx];
//    }
//}

void DNAlmar(string dna , int limit)
{
    int i=0;

    string tmp = "";

    for(i=0; i<dna.length()-(limit-1); i++)
    {
        tmp = dna.substr(i , limit);

        if(!mp.count(tmp))
        {
            resDNA.push_back(tmp); // DNA r l-mar length er unique substring gulare resDNA name e vector er vitore push korsi
            mp[tmp] += 1; // dna substring gular frequency prothome ek korsi
        }

        else
        {
            mp[tmp]+=1; // pore same substring gular jonno ek ek kore baraisi
        }
    }
}

void RNAlmar(string rna , int limit)
{
    int i=0;

    string tmp = "";

    for(i=0; i<rna.length()-(limit-1); i++)
    {
        tmp = rna.substr(i , limit);

        if(!mp.count(tmp))
        {
            resRNA.push_back(tmp); // RNA r l-mar length er unique substring gulare resRNA name e vector er vitore push korsi

            mp[tmp] += 1; // rna substring gular frequency prothome ek korsi
        }

        else
        {
            mp[tmp]+=1; // pore same substring gular jonno ek ek kore baraisi
        }
    }
}

void showDNA() // dna sequence ar tader frequency print korsi 
{
    cout << "\n***** DNA l-mar substrings ******\n";

    for(int i=0; i<resDNA.size(); i++)
    {
        cout << resDNA[i] << " " << mp[resDNA[i]] << "\n";
    }
}

void showRNA() // rna sequence ar tader frequency print korsi
{
    cout << "\n***** RNA l-mar substrings ******\n";

    for(int i=0; i<resRNA.size(); i++)
    {
        cout << resRNA[i] << " " << mp[resRNA[i]] << "\n";
    }
}

int main()
{
    ifstream fin; // ifstream hocche, file read korar ekta c++ keyword, fin hocche ekta fstream variable 
    fin.open("RandomSequence_of_DNA_and_RNA.txt"); // variable_name.open diye je file ta read kora lagbe sheita age open korte hobe
    getline(fin , dna); // getline(fin, dna) diye dna r pura ekta line ke read korsi jeta RandomSequence_of_DNA_and_RNA.txt ei file er moddhe ache
    getline(fin , rna); // eibar rna r pura ekta line ke read korsi jeta RandomSequence_of_DNA_and_RNA.txt ei file er moddhe ache
    cout << "\nDNA sequence: " << dna << "\nRNA sequence: " << rna << "\n";
    cout << "\nEnter l-mar: ";
    cin >> lmar;
    DNAlmar(dna , lmar);
    showDNA();
    mp.clear(); // map clear korsi
    RNAlmar(rna , lmar);
    showRNA();
    return 0;
}
