// Task-01: Generate Random DNA Sequence for K length
// Author: Pranta Sarker

#include<iostream>
#include<string>
#include<utility>
#include<algorithm>

using namespace std;

char DNA[]={'A', 'T', 'C', 'G'}; // DNA array nisi, zekhane DNA r sob nucleotide gula ache

void generateDNASequence(int limit) // limit re pass korsi, limit mane ami koto length er DNA sequence chai
{
    for(int i=0; i<limit; i++)
    {
        int range = (3 - 0) + 1;
        int num = ( rand() % range ) + 0; // 0 theke 3 porzonto random number generate korsi
        cout << DNA[num]; // oi random number er jonno DNA nucleotide print korsi
    }
}

int main()
{
    int len;

    cout << "Enter Length to see Random DNA Sequence: ";

    while(cin >> len)
    {
        cout << "\nDNA Sequence is : ";

        generateDNASequence(len); // function call korsi

        cout << "\n\nEnter Length to see Random DNA Sequence: ";
    }

    return 0;
}
