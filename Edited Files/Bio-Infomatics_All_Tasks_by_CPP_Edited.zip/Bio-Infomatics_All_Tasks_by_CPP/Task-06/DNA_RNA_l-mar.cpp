#include<iostream>
#include<string>
#include<cstring>
#include<map>
#include<vector>
#include<utility>
#include<random>
#include<set>

using namespace std;

typedef map<string, bool>mpsb;
typedef vector<string>vs;

char DNA[4] = {'A' , 'T' , 'C' , 'G'}; // DNA array nisi, zekhane DNA r sob nucleotide gula ache
char RNA[4] = {'A' , 'U' , 'C' , 'G'}; // RNA array nisi, zekhane RNA r sob nucleotide gula ache

string dna = "" , rna = "";  // dna ar rna name e duita string variable nisi 

mpsb mp; // string and bool type ekta map nisi
vs resDNA, resRNA; // resDNA ar resRNA name e duita string type er vector nisi

void takeDNASequence(int limit) // limit re pass korsi, limit mane ami koto length er DNA sequence chai
{
    int i=0;

    for(i=0; i<limit; i++)
    {
        int range = (3 - 0) + 1;
        int indx = ( rand() % range ) + 0; // 0 theke 3 porzonto random number generate korsi
        dna += DNA[indx]; // oi random number er jonno DNA nucleotide ke oi string variable dna e add korsi
    }
}

void takeRNASequence(int limit)
{
    int i=0;

    for(i=0; i<limit; i++)
    {
        int range = (3 - 0) + 1;
        int indx = ( rand() % range ) + 0; // 0 theke 3 porzonto random number generate korsi
        rna += RNA[indx]; // oi random number er jonno DNA nucleotide ke oi string variable rna e add korsi
    }
}

void DNAlmar(string dna , int limit)
{
    int i=0;

    string tmp = "";

    for(i=0; i<dna.length()-(limit-1); i++)
    {
        tmp = dna.substr(i , limit);

        if(!mp.count(tmp))
        {
            resDNA.push_back(tmp); // DNA r l-mar length er unique substring gulare resDNA name e vector er vitore push korsi
        }

        mp[tmp] = 1;
    }
}

void RNAlmar(string rna , int limit)
{
    int i=0;

    string tmp = "";

    for(i=0; i<rna.length()-(limit-1); i++)
    {
        tmp = rna.substr(i , limit);

        if(!mp.count(tmp))
        {
            resRNA.push_back(tmp); // RNA r l-mar length er unique substring gulare resRNA name e vector er vitore push korsi
        }

        mp[tmp] = 1;
    }
}

void showDNA() // dna sequence print korsi
{
    cout << "\n***** DNA l-mar substrings ******\n";

    for(int i=0; i<resDNA.size(); i++)
    {
        cout << resDNA[i] << "\n";
    }
}

void showRNA() // rna sequence print korsi
{
    cout << "\n***** RNA l-mar substrings ******\n";

    for(int i=0; i<resRNA.size(); i++)
    {
        cout << resRNA[i] << "\n";
    }
}

int main()
{
    int length = 0 , lmar;
    cout << "Enter Sequence Length(0 to end): ";
    cin >> length;
    while(length)
    {
        dna = "";
        rna = "";
		// dna ar rna string variable gulare initialize korsi
		// niche sob map gulare clear korsi
        mp.clear();
        resDNA.clear();
        resRNA.clear();
        takeDNASequence(length);
        takeRNASequence(length);
        cout << "\nDNA sequence: " << dna << "\nRNA sequence: " << rna << "\n";
        cout << "\nEnter l-mar: ";
        cin >> lmar;
        DNAlmar(dna , lmar);
        mp.clear();
        RNAlmar(rna , lmar);
        showDNA();
        showRNA();
        cout << "\nEnter Sequence Length(0 to end): ";
        cin >> length;
    }
    cout << "\n<<<< End terminal >>>>\n";
    return 0;
}
